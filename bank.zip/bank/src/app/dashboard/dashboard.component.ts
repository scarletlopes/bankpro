import { Component, OnInit } from '@angular/core';
// import { DBConnect } from '../shared/dbconnect.service';
@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }
  // loadedPosts:any[] = [];
  // isFetching = false;
  // loadUser(){
  //   this.ser.loadUserFromDB().subscribe(
  //     posts => {
  //       this.isFetching = false;
  //       this.loadedPosts = posts;
  //     }
  //   )
    
    
  // }
}
